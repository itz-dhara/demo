'''2. Write a Python program that loops from 1 to 20 and prints each number. If the number is
divisible by 7, the loop should stop.'''
for i in range(1,20):
    print(i)
    '''if  i==7:
        continue'''
    if i%7==0:
        break
    else:
        continue
