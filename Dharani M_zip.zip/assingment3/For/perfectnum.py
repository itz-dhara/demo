'''4. Write Python Program to check the given number is perfect number or not?'''
n=int(input("Enter a number:"))
sum=1
for i in range(1,n):
    if n%i==0:
        sum*=i
if sum==n:
    print(f"{n} is perfect number")
else:
    print(f"{n} is not perfect number")
