'''7. Number checker num = 5, if num>0, print “The number is positive”, else if num<0, print ”The
number is negative”, else print ”The number is zero”?'''
n=5
if(n>0):
    print(f"{n} is positive")
elif(n==0):
    print(f"{n} is zero")
elif n<0 :
    print(f"{n} is negative")
