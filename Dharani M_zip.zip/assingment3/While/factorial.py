'''2. Write a Python program to find factorial of a number?'''
n=int(input('Enter the number:'))
a=1
b=1
while b<=n:
    a*=b
    b+=1
    print(f"factorial of {b} is {a}")
