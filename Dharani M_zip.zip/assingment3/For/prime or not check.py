'''5. Write Python Program to check the no is prime or not?'''
for num in range(1,100):
    for i in range(2,num+1):
        if num % i==0:
            print("------------------------|")
            print(f"{num} is not a prime number|")
            print("------------------------|")
            break
        else:
            print(f"                        |      {num} is prime")
            break
