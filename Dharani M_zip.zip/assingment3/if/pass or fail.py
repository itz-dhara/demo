#1. Get input for variable mark. If mark>35 print Pass. Else print Fail ?
a=int(input("Enter your mark:"))
if(a>=35 and a<=90):
    print("you are pass")
elif(a>90):
    print("you are great, keep it up")
else:
    print("you are Fail, better luck next time")
