''' 1. Write a Python program to find sum of n numbers?'''
n=int(input('Enter the number:'))
a=0
b=1
while b<=n:
    a+=b
    b+=1
    print(f"sum of {b} is {a}")
