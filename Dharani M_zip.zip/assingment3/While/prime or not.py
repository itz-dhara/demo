'''7. Write a Python program to find give number is prime or not.'''
n=int(input("Enter a number:"))
if n<=1:
    print("It is not a prime number")
else:
    div=2
    is_prime = True

    while div <= n //2:
        if n % div  ==0:
            is_prime=False
            break
        div +=1
    if is_prime:
        print(f"{n} is a prime number")
    else:
        print(f"{n} is not prime number")
