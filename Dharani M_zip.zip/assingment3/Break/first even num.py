'''1. Finding the First Even Number in a List'''
for i in range(1,10):
    print(i)
    if i%2==0:
        break
    else:
        continue
        
        
