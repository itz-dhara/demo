'''4.) Get a input for score percentage. Only if the percentage is greater than 70, get input for his
name, department and location. Then print you are eligible. If not print you are not eligible ?'''
per=int(input("Enter your score:"))
if(per>=70):
    print("Your eligiable")
    n=str(input("Enter your name:"))
    de=str(input("Enter your department:"))
    lo=str(input("Enter your location:"))
    print(f'Name:{n}')
    print(f'department:{de}')
    print(f'location:{lo}')
else:
    print("your out")
