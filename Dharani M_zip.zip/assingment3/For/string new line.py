'''9. Write a Python program that takes a string as input and prints each character on a new line
using a for loop.'''
n=input("Enter your name:")
for i in n:
    print(i)
