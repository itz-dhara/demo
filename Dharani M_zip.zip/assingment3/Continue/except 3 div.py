'''3. Create a Python program that loops from 1 to 20 and prints all numbers except those
divisible by 3. Use continue to skip numbers divisible by 3.'''
for i in range(1,20):
    if i%3==0:
        continue
    else:
        print(i)
