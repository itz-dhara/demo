'''2.) Get input for a number and check whether it is divisible by both 3 and 5 or not. If yes
print,the number is divisible by 3 and 5, else the number is not divisible by 3 and 5 ?'''
n=int(input("Enter the number:"))
if(n%3==0 and n%5==0):
    print(f"{n} is divisiable by both 3 and 5")
else:
    print(f"{n} is not divisiable by both 3 and 5")
