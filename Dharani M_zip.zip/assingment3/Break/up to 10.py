'''5. to print range of numbers upto 10'''
w=1
while w>0:
    w+=1
    print(w,end='')
    if w==1213:
        print("Destination reached")
        break
