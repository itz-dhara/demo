'''6. Get input for five subject marks. Add all of it, and find average. If average mark is less than 35
print “Additional class is required” else print “You are good to go” ?'''
a=int(input("Enter mark:"))
b=int(input("Enter mark:"))
c=int(input("Enter mark:"))
d=int(input("Enter mark:"))
e=int(input("Enter mark:"))
add=a+b+c+d+e
av=add/5
print(f"Average:{av}")
if(av>=35):
    print("you are good to go")
else:
    print("you need extra classes,feel sorry for you")
