'''2. Write Python Program to print fibonacci series?'''
n=int(input("Enter n:"))
a,b = 0, 1
print("fibonacci series:")
for i in range (0,n):
    print(f"{i}-------->>>{a}")
    a,b = b, a+b
