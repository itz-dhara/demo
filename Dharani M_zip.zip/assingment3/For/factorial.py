'''3. Write Python Program to find factors of a given number?'''
n=int(input("Enter a number:"))
print(f"Factors of {n} are:")
for i in range(1,1345):
    if n%i==0:
        print(i)


