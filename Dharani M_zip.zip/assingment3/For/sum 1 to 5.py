'''8. Write a Python program that calculates the sum of all numbers from 1 to 50 using a for loop.'''
n=0
for i in range(1,50):
    n+=i
    print(n)
