'''3.) Make a mini calculator. Get input for 2 numbers a and b, Get input from user
add/sub/mul/div. If user select add then add the two number and print result ?'''
a=int(input("Enter value A:"))
b=int(input("Enter value B:"))
o=input("Enter a operator +,-,*,/")
if(o=='+'):
    q=a+b
    print(q)
elif(o=='-'):
    q=a-b
    print(q)
elif(o=='*'):
    q=a*b
    print(q)
elif(o=='/'):
    if(b==0):
        print("cannot divisiable by Zero")
    else:
         q=a/b
         print(q)
