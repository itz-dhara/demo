'''1.) Write Python Program to print nos divisible by 5 not by 10 using for loop?'''
print("Numbers divisiable by 5 but not by 10")
for i in range(1,100+1):
    if(i%5==0 and i%10!=0):
       print(i)
