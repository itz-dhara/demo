'''4. Write a program that asks the user to input a password repeatedly. If the user enters
"password123", print "Access Granted" and break out of the loop. Otherwise, keep asking for
the password.'''
n=1
while n>0:
    pas=input("Enter your password:")
    if pas=="password123":
        print("Access Granted")
        break
    else:
        continue
