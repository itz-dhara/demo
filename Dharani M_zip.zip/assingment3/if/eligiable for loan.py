'''5.) Get input for salary and age. If salary greater than or equal to 20000 or age less than or equal
to 25, get input for required loan amount. If not print you are not eligible for loan. If required
loan amount is 500000 print maximum loan amount is 500000 ?'''
sal=int(input("Enter your salary:"))
age=int(input("Enter your age:"))
if(sal>=20000 and age>=25):
    print("Your eligiable for loan")
    loan=int(input("Enter your loan amount(500000):"))
    if(loan>500000):
        print("maximum is only 500000,sorry")
    else:
        print("Your loan amount will credit on your account,THANK YOU")
