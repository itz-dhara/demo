'''3. Write a Python program to find sum of digits of a number?'''
n = int(input('enter the number: '))
r = 0
sum = 0
while (n>0):
 r = n%10
 n = n//10
 sum = sum + r
print(sum)
