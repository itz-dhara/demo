'''6. to find first 5 numbers for multiples of 6. '''
count=0
for i in range(1,100):
    if i%6==0:
        count +=1
        print(f"count={count} multiples={i}")
        if count==5:
            break
        else:
            continue
    else:
        continue
