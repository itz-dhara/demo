'''1. Write a Python program that loops from 1 to 15 and prints only the odd numbers. Use the
continue statement to skip even numbers.'''
for i in range(1,16):
    if i%2==0:
        continue
    else:
        print(i)
