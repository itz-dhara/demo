'''6. Write a Python Program to check the number is palindrome or not?'''
text = input("Enter a string or number: ")
start = 0
end = len(text) - 1
is_palindrome = True

while start < end:
    if text[start] != text[end]:
        is_palindrome = False
        break
    start += 1
    end -= 1

if is_palindrome:
    print(text, "is a palindrome.")
else:
    print(text, "is not a palindrome.")

