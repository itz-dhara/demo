'''5. Write a Python Program to find number is Armstrong number or not?'''
num = int(input("Enter a number:"))
order = len(str(num))
s = 0
t = num

while t >= 0 :
    digi = t % 10
    s += digi ** order
    t //= 10
    
    if s == num:
        print("amstrong")
    else:
        print("not")
