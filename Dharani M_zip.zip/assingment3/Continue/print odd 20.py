'''2. to print odd numbers from 1 to 20'''
for i in range(1,20):
    if i%2==0:
        continue
    else:
        print(i)
